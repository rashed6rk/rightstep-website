import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { useTranslations } from "next-intl";
import { PageHero } from "@/components/PageHero";
import { CtaBand } from "@/components/CtaBand";
import { ArrowIcon, Container, SectionHeading } from "@/components/ui";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta.about" });
  return { title: t("title"), description: t("description") };
}

export default async function AboutPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  return <AboutPageContent />;
}

type Value = { title: string; body: string };
type Journey = { audience: string; from: string; to: string; body: string };

function AboutPageContent() {
  const t = useTranslations("aboutPage");
  const values = t.raw("values.items") as Value[];
  const journeys = t.raw("journeys.items") as Journey[];

  return (
    <>
      <PageHero title={t("hero.title")} body={t("hero.body")} />

      {/* ---------- Vision & Mission ----------
          Two panels, deliberately unequal in weight: the vision is the quiet
          belief, the mission is the commitment, so the mission gets the navy. */}
      <section className="bg-surface py-16 sm:py-24">
        <Container>
          <div className="grid gap-5 lg:grid-cols-2">
            <article className="flex h-full flex-col justify-center gap-4 rounded-2xl border border-line bg-surface p-7 sm:p-10">
              <h2 className="text-[1.75rem] leading-[1.08] font-bold text-heading sm:text-[2.15rem]">
                {t("vision.title")}
              </h2>
              <p className="max-w-[54ch] text-base leading-relaxed text-pretty text-ink-muted">
                {t("vision.body")}
              </p>
            </article>

            <article className="flex h-full flex-col justify-center gap-4 rounded-2xl bg-navy p-7 text-white sm:p-10">
              <h2 className="text-[1.75rem] leading-[1.08] font-bold text-balance sm:text-[2.15rem]">
                {t("mission.title")}
              </h2>
              <p className="max-w-[54ch] text-base leading-relaxed text-pretty text-white/75">
                {t("mission.body")}
              </p>
            </article>
          </div>
        </Container>
      </section>

      {/* ---------- Values ---------- */}
      <section className="bg-surface-alt py-16 sm:py-24">
        <Container>
          <SectionHeading title={t("values.title")} />

          <ul className="mt-12 grid gap-x-14 sm:grid-cols-2">
            {values.map((value) => (
              <li key={value.title} className="border-t border-line py-6">
                <h3 className="text-lg font-bold text-heading">{value.title}</h3>
                <p className="mt-2 max-w-[52ch] text-sm leading-relaxed text-pretty text-ink-muted">
                  {value.body}
                </p>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      {/* ---------- The three journeys ---------- */}
      <section className="bg-surface py-16 sm:py-24">
        <Container>
          <SectionHeading title={t("journeys.title")} />

          <ul className="mt-12 grid gap-6 lg:grid-cols-3">
            {journeys.map((journey, i) => {
              const accent = ["text-teal-ink", "text-gold-ink", "text-heading"][i];
              return (
                <li
                  key={journey.audience}
                  className="border-t border-line pt-6"
                  // Each journey starts one tread higher than the last.
                  style={{ marginBlockStart: `${i * 6}px` }}
                >
                  <article className="flex h-full flex-col">
                    <h3 className="text-xl font-bold text-heading">
                      {journey.audience}
                    </h3>

                    {/* From → To, read as a single climb rather than a boxed pair */}
                    <div className="mt-5 flex flex-col gap-2">
                      <p className="text-sm leading-snug text-ink-muted">
                        {journey.from}
                      </p>
                      <ArrowIcon
                        className={`h-4 w-4 rotate-90 ${accent} rtl:-scale-x-100`}
                      />
                      <p className="text-sm leading-snug font-bold text-heading">
                        {journey.to}
                      </p>
                    </div>

                    <p className="mt-5 text-sm leading-relaxed text-pretty text-ink-muted">
                      {journey.body}
                    </p>
                  </article>
                </li>
              );
            })}
          </ul>
        </Container>
      </section>

      {/* ---------- Abu Dhabi ---------- */}
      <section className="bg-surface pb-16 sm:pb-24">
        <Container>
          <div className="relative overflow-hidden rounded-3xl bg-navy-deep px-6 py-12 text-white sm:px-10 sm:py-16">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0"
            >
              <div className="tread-lines absolute inset-0 opacity-70" />
              <div className="absolute -bottom-20 end-[-5%] h-72 w-72 rounded-full bg-teal/20 blur-[110px]" />
            </div>
            <div className="relative flex max-w-2xl flex-col gap-4">
              <h2 className="text-[1.75rem] leading-[1.08] font-bold text-balance sm:text-[2.4rem]">
                {t("location.title")}
              </h2>
              <p className="max-w-[58ch] text-base leading-relaxed text-pretty text-white/75">
                {t("location.body")}
              </p>
            </div>
          </div>
        </Container>
      </section>

      <CtaBand />
    </>
  );
}
