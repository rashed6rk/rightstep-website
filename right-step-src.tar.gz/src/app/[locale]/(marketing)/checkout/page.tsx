import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { ServiceKey } from "@/lib/site";
import { CheckoutClient, type Workshop } from "@/components/CheckoutClient";
import { Container, CtaButton } from "@/components/ui";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta.checkout" });
  return {
    title: t("title"),
    description: t("description"),
    robots: { index: false, follow: true },
  };
}

export default async function CheckoutPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ w?: string }>;
}) {
  const { locale } = await params;
  const { w } = await searchParams;
  setRequestLocale(locale);

  const tWorkshops = await getTranslations({ locale, namespace: "workshops" });
  const tServices = await getTranslations({
    locale,
    namespace: "servicesOverview",
  });
  const t = await getTranslations({ locale, namespace: "checkout" });

  const workshops = tWorkshops.raw("items") as Workshop[];
  const workshop = workshops.find((item) => item.id === w);

  // Arriving with no `w`, or with an id that no longer exists once the schedule
  // is updated, is an ordinary path — not an error page.
  if (!workshop) {
    return (
      <section className="bg-surface pt-[72px] sm:pt-20">
        <Container>
          <div className="flex max-w-xl flex-col items-start gap-5 py-20 sm:py-28">
            <h1 className="text-[2rem] leading-[1.05] font-extrabold text-balance text-heading sm:text-[2.5rem]">
              {t("emptyTitle")}
            </h1>
            <p className="text-base leading-relaxed text-pretty text-ink-muted">
              {t("emptyBody")}
            </p>
            <CtaButton href="/#workshops">{t("emptyCta")}</CtaButton>
          </div>
        </Container>
      </section>
    );
  }

  const services = tServices.raw("items") as {
    key: ServiceKey;
    title: string;
  }[];
  const practiceName =
    services.find((s) => s.key === workshop.practice)?.title ?? "";

  return (
    <CheckoutClient
      workshop={workshop}
      practiceName={practiceName}
      maxSeats={seatCap(workshop.seats)}
    />
  );
}

/**
 * Seat counts are localized display strings ("14" / "١٤"), so normalise both
 * numeral systems before parsing, and cap the stepper at 10 — a bigger group
 * is a private session, which is a conversation rather than a checkout.
 */
function seatCap(seats: string) {
  const normalised = [...seats]
    .map((ch) => {
      const arabicIndex = "٠١٢٣٤٥٦٧٨٩".indexOf(ch);
      return arabicIndex >= 0 ? String(arabicIndex) : ch;
    })
    .join("");
  const available = Number.parseInt(normalised.replace(/[^\d]/g, ""), 10);
  return Number.isFinite(available) && available > 0
    ? Math.min(available, 10)
    : 10;
}

// searchParams makes this route dynamic anyway; stating it keeps the intent
// obvious next to a page that must never be cached per-visitor.
export const dynamic = "force-dynamic";
