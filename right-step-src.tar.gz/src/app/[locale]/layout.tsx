import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { NextIntlClientProvider, hasLocale } from "next-intl";
import { getTranslations, setRequestLocale } from "next-intl/server";
import {
  Bricolage_Grotesque,
  IBM_Plex_Sans,
  IBM_Plex_Sans_Arabic,
} from "next/font/google";
import { routing, localeDirection, type Locale } from "@/i18n/routing";
import { HashScroll } from "@/components/HashScroll";
import "../globals.css";

// Display voice. Bricolage Grotesque is a variable face with a real optical
// size axis, so headlines tighten as they grow instead of just scaling up.
// Loaded as a true variable font: the wght axis comes as standard and `opsz`
// is requested explicitly, which is the whole reason for choosing this face.
// (next/font rejects a fixed `weight` list alongside `axes`.)
const bricolage = Bricolage_Grotesque({
  subsets: ["latin"],
  axes: ["opsz"],
  variable: "--font-bricolage",
  display: "swap",
});

// Reading voice. IBM Plex Sans is chosen for one specific reason: its Arabic
// sibling is the Arabic face this site uses, so both scripts come from the
// same superfamily — matching proportions, weights and rhythm — rather than
// two unrelated fonts sharing a page.
const plex = IBM_Plex_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-plex",
  display: "swap",
});

const plexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-plex-arabic",
  display: "swap",
});

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta.home" });

  return {
    // Required for absolute OG/Twitter URLs — scrapers ignore relative paths.
    // Set NEXT_PUBLIC_SITE_URL to the live domain before launch.
    metadataBase: new URL(
      process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3100",
    ),
    title: { default: t("title"), template: "%s" },
    description: t("description"),
    // Without these, every link shared on WhatsApp or LinkedIn renders as a
    // bare URL: no title, no description, no image. WhatsApp is the main
    // sharing channel in the Gulf, so this directly costs click-throughs.
    openGraph: {
      type: "website",
      siteName: t("title"),
      title: t("title"),
      description: t("description"),
      locale: locale === "ar" ? "ar_AE" : "en_AE",
      alternateLocale: locale === "ar" ? "en_AE" : "ar_AE",
    },
    twitter: {
      card: "summary_large_image",
      title: t("title"),
      description: t("description"),
    },
    alternates: {
      canonical: `/${locale}`,
      languages: { "en-AE": "/en", "ar-AE": "/ar" },
    },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) notFound();

  setRequestLocale(locale);
  const dir = localeDirection[locale as Locale];
  const t = await getTranslations({ locale, namespace: "nav" });

  return (
    <html
      lang={locale}
      dir={dir}
      className={`${bricolage.variable} ${plex.variable} ${plexArabic.variable}`}
      suppressHydrationWarning
    >
      <body>
        <NextIntlClientProvider>
          <a
            href="#main"
            className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-navy focus:px-4 focus:py-2 focus:text-sm focus:font-bold focus:text-white"
          >
            {t("skip")}
          </a>
          <HashScroll />
          {/* Chrome belongs to the route group: the marketing site gets the
              header and footer, the client portal gets its own shell. */}
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
